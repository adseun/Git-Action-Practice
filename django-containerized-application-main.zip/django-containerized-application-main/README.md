# To-do-App
To-do app can create to-dos with update, delete and completed todos.

# To-do
It contains 3 pages:
1. Home page (all todos are listed with update, delete, completion buttons).
2. Completed Todos
3. Create Todos
